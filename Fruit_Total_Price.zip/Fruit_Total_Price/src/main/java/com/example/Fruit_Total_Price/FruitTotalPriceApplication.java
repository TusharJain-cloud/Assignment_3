package com.example.Fruit_Total_Price;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitTotalPriceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitTotalPriceApplication.class, args);
	}

}
