package com.example.Fruit_Total_Price;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitTotalPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
