package com.example.Fruit_Month_Price;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitMonthPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
